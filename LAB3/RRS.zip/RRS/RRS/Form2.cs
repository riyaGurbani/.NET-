﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace RRS
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stream st;
            OpenFileDialog d1 = new OpenFileDialog();
            if(d1.ShowDialog() == DialogResult.OK)
            {
                if((st = d1.OpenFile()) != null)
                {
                    string file = d1.FileName;
                    String str = File.ReadAllText(file);
                    richTextBox1.Text = str;
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter tw = new StreamWriter(@"E:\Christ University MCA\5 MCA\.NET\abc.txt");
            tw.Write(richTextBox1.Text);
            MessageBox.Show("File saved");
            Random r = new Random();
            tw.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowColor = true;
            if(fontDialog.ShowDialog() == DialogResult.OK & !string.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionFont = fontDialog.Font;
                richTextBox1.SelectionColor = fontDialog.Color;
            }
        }
    }
}
