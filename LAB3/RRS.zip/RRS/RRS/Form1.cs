﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;

namespace RRS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void b1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBox1.Image = new Bitmap(open.FileName);
                // image file path  
                //label5.Text = open.FileName;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {



            var selected = listBox1.SelectedItem.ToString();
            var txt = textBox1.Text;
            var phone = textBox2.Text;
            var name = textBox3.Text;
            /* string str = " ";
            if (checkBox1.Checked)
            {
                str = " " + checkBox1.Text;
            }
            if (checkBox2.Checked)
            {
                str = " " + checkBox2.Text;
            }
            if (checkBox3.Checked)
            {
                str = " " + checkBox3.Text;
            }
            */


            List<string> strList = new List<string>();
            if (checkBox1.Checked)
                strList.Add(checkBox1.Text);
            if (checkBox2.Checked)
                strList.Add(checkBox2.Text);
            if (checkBox3.Checked)
                strList.Add(checkBox3.Text);
            string res = string.Join("、", strList.ToArray());
            label1.Text = " Your are from " + selected + "\n Your Phone number is: " + phone + "\n Name: " + name + "\n Problem at this location is: " + res + "\n " + txt;



        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://dir.indiamart.com/impcat/road-repair-services.html");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.ShowDialog();


        }

        private void button3_Click(object sender, EventArgs e)
        {

            SqlConnection sc = new SqlConnection();
            SqlCommand com = new SqlCommand();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\Christ University MCA\5 MCA\.NET\RRS\RRS\Database1.mdf;Integrated Security=True");
            sc.Open();
            com.Connection = sc;
            com.CommandText = ("INSERT INTO data (mobile_number, name, city, concern) VALUES ('" + textBox2.Text + "','" + textBox3.Text + "','" + listBox1.Text + "','" + textBox1.Text + "');");
            com.ExecuteNonQuery();
            MessageBox.Show("Record Inserted Successfully");

            sc.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection sc = new SqlConnection();
            SqlCommand com = new SqlCommand();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\Christ University MCA\5 MCA\.NET\RRS\RRS\Database1.mdf;Integrated Security=True");
            sc.Open();
            SqlCommand cmd = new SqlCommand("update data set name='" + textBox3.Text + "' where mobile_number='" + textBox2.Text + "'", sc);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Updated Successfully.");
            sc.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (!(textBox2.Text == string.Empty))
            {
                SqlConnection sc = new SqlConnection();
                SqlCommand com = new SqlCommand();
                sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\Christ University MCA\5 MCA\.NET\RRS\RRS\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand cmd = new SqlCommand("Delete from data where mobile_number= '" + this.textBox2.Text + "'", sc);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Deleted Successfully.");
                sc.Close();

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox2.Checked = false;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            listBox1.ClearSelected();
            label1.Text = "";



        }
    }
}