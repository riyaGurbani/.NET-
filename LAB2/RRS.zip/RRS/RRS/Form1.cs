﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace RRS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void b1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBox1.Image = new Bitmap(open.FileName);
                // image file path  
                //label5.Text = open.FileName;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
             
            

            var selected = listBox1.SelectedItem.ToString();
            var txt = textBox1.Text;
            var phone = textBox2.Text;
            var name = textBox3.Text;
            /* string str = " ";
            if (checkBox1.Checked)
            {
                str = " " + checkBox1.Text;
            }
            if (checkBox2.Checked)
            {
                str = " " + checkBox2.Text;
            }
            if (checkBox3.Checked)
            {
                str = " " + checkBox3.Text;
            }
            */


            List<string> strList = new List<string>();
            if (checkBox1.Checked)
                strList.Add(checkBox1.Text);
            if (checkBox2.Checked)
                strList.Add(checkBox2.Text);
            if (checkBox3.Checked)
                strList.Add(checkBox3.Text);
            string res = string.Join("、", strList.ToArray());
            label1.Text = " Your are from " + selected + "\n Your Phone number is: " + phone + "\n Name: " + name + "\n Problem at this location is: " + res + "\n " + txt ;



        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://dir.indiamart.com/impcat/road-repair-services.html");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.ShowDialog();


        }
    }
}
